package com.employee.management.models;

public class TaxModel {

}
