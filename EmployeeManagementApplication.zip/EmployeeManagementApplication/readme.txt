##Read Me file

We have created a Spring Boot project and have exposed an API which client can use to get the pay Details.
We have write Java tests also which we can use to see the JSON Output.
We have also Included negative test cases to test negative testing of a project as well.


We can change the behavior of the Spring application by providing the relevant property in Properties file.